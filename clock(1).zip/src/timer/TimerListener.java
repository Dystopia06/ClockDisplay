package timer;

import java.util.EventListener;

@FunctionalInterface
public interface TimerListener extends EventListener {
    void tick(TimerEvent event);

}

