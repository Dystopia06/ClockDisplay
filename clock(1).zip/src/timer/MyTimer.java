package timer;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MyTimer {
    private final static long ZZZ = 1000;
    private final long DELAY = 0;
    private long zzz;
    private final List<TimerListener> listeners = new ArrayList<>();
    private long zeroTime = 0;
    private Timer timer;
    private TimerTask timerTask;
    private boolean running;
    private final static String THREAD_NAME = "Timer thread";

    public MyTimer() {
        this(ZZZ);
    }

    public MyTimer(long zzz) {
        super();
        this.zzz = zzz;

    }

    public void start() {
        if (timer == null) {
            timer = new Timer(THREAD_NAME);
        }
        restart();
    }
    /*
     * Warning - contains Voodoo!
     * Creates a timer task and starts the timer running, if there's no
     * timer running yet.
     */
    private void restart() {
        if (!running) {
            zeroTime = System.currentTimeMillis();
            // TimerTask is an abstract class so we need to create an
            //  anonymous inner (sub)class and override the abstract method
            timerTask = new TimerTask(){
                // creates a new timer event and fires it at listeners
                @Override
                public void run() {
                    fireTimerEvent(new TimerEvent(this,
                            System.currentTimeMillis() - zeroTime));
                }
            };
            timer.schedule(timerTask, DELAY, zzz);
            running = true;
        }
    }

    /*
     * Stops timer.
     */
    public void pause() {
        timerTask.cancel();
        running = false;
    }

    public void addTimerListener(TimerListener l) {
        listeners.add(l);
    }

    public void removeTimerListener(TimerListener l) {
       listeners.remove(l);
    }

    private void fireTimerEvent(TimerEvent evt) {
        //code to deliver event to each listener
        for(TimerListener lis : listeners){
            lis.tick(evt);
        }
    }
}

