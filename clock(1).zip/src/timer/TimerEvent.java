package timer;

import java.util.EventObject;

@SuppressWarnings("serial")  // don't ask  :^)
public class TimerEvent extends EventObject {
    private long time;  // system time of event

    TimerEvent(Object source) {
        this(source, System.currentTimeMillis());
    }

    public TimerEvent(Object source, long time) {
        super(source);
        this.time = time;
    }

    public long getTime() {
        return time;
    }
}

