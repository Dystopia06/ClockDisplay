package main;


import clock.text.Clock;
import javafx.application.Application;

import timer.MyTimer;


/*
 All the clocks together off the same timer
*/
public class Main {
    public static void main(String[] args) {
        MyTimer myTimer = new MyTimer(1000);
        myTimer.start();

         //text-based
         myTimer.addTimerListener( new Clock("A - "));
         myTimer.addTimerListener( new Clock("B - "));

         //swing-based
        myTimer.addTimerListener(new clock.gui.swing.digital.Clock());


         //fx-based
        new clock.gui.fx.digital.Clock();
        clock.gui.fx.digital.Clock.setTimer(myTimer);
        Application.launch(clock.gui.fx.digital.Clock.class,args);

        //Mettre en commentaire juste au dessus si on veut tester la version analogique ( et retirer le commenatire en dessous )

        // fx-based : analog

        clock.gui.fx.analog.Clock c = new clock.gui.fx.analog.Clock();
        clock.gui.fx.analog.Clock.setTimer(myTimer);
        //Application.launch(clock.gui.fx.analog.Clock.class, args);

        //Retirer le commentaire juste au dessus pour faire fonctionner la version analogique


    }


}
