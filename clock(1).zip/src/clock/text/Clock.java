package clock.text;

import timer.TimerEvent;
import timer.TimerListener;

public class Clock implements TimerListener{
   private final String nom;

    public Clock(String nom) {
        this.nom = nom;
    }

    public void tick(TimerEvent evt) {
        System.out.println(this.nom + evt.getTime());
    }
}

