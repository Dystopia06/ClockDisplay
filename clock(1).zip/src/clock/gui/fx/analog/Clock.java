package clock.gui.fx.analog;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

import clock.ClockDisplay;
import timer.MyTimer;
import timer.TimerEvent;
import timer.TimerListener;


/**
 * A very simple GUI (graphical user interface) for the clock display.
 * This version uses the minimum JavaFX possible.
 * There are however a couple of curiosities:
 * - There seems to be no way to get a reference to this object from
 *   outside this object. So we can't register it directly as a
 *   timer listener with a timer event source. Instead we use a static
 *   method to inject a timer event source into this class, where
 *   we can then register the current object. A hack until something
 *   better comes up.
 * - Things run in different threads. The timer runs in its own thread,
 *   the FX application runs in another thread. This creates a few
 *   issues for the timer listener method affecting the GUI - they must
 *   run in the same thread.
 *
 * @author Michael Kölling and David J. Barnes
 * @author Peter Sander
 */
public class Clock extends Application implements TimerListener {
    private static MyTimer timer;
    private final ClockDisplay clockDisplay;

    int seconds;
    int minutes;
    int hours;
    GraphicsContext gc;
    final Canvas canvas = new Canvas(300, 250);


    /**
     * Constructor builds a clock display which determines how the time
     * will be displayed.
     */
    public Clock() {
        clockDisplay = new ClockDisplay();
    }

    /**
     * This is kind of a kluge in order to inject a timer object.
     * It must be invoked before main.
     *
     * @param timer A timer event source.
     */
    public static void setTimer(MyTimer timer) {
        Clock.timer = timer;
    }

    /**
     * Called automagically upon launching the application. Runs in the
     * FX initialization thread, not the FX application thread. Beware.
     * Registers the current object as a timer listener.
     */
    @Override
    public void init() {
        timer.addTimerListener(this);
    }

    @Override
    public void stop() {
        System.out.println("Outta here");
    }

    /**
     * Called automagically upon launching the application. Runs in the
     * FX application thread.
     */
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("FX-based Clock");
        BorderPane root = new BorderPane();
        root.getChildren().add(canvas);

        //adds pane for buttons
        FlowPane buttonPane = new FlowPane();
        root.setBottom(buttonPane);
        buttonPane.setAlignment(Pos.CENTER);
        // add start button
        Button startBtn = new Button("Start");
        startBtn.setOnAction(evt -> timer.start());
        buttonPane.getChildren().add(startBtn);
        // add pause button
        Button pauseBtn = new Button("Pause");
        pauseBtn.setOnAction(evt -> Clock.timer.pause());
        buttonPane.getChildren().add(pauseBtn);
        // add reset button
        Button resetBtn = new Button("Reset");
        resetBtn.setOnAction(evt -> {
            clockDisplay.setTime(0, 0, 0);

        });
        buttonPane.getChildren().add(resetBtn);
        //add quit button
        Button quitBtn = new Button("Quit");
        quitBtn.setOnAction(evt -> Platform.exit());
        buttonPane.getChildren().add(quitBtn);
        // constructs scene

        canvas.widthProperty().bind(root.widthProperty());
        canvas.heightProperty().bind(root.heightProperty());
        gc = canvas.getGraphicsContext2D();
        canvas.widthProperty().addListener(event -> drawClock(gc));
        canvas.heightProperty().addListener(event -> drawClock(gc));
        drawClock(gc);
        Scene scene = new Scene(root, 500, 450);
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    /**
     * Obligatory TimerListener method.
     *
     * @param evt The event fired by a TimerEvent source.
     */
    @Override
    public void tick(TimerEvent evt) {
        clockDisplay.timeTick();

        seconds = Integer.parseInt(clockDisplay.getTime().substring(6, 8));
        minutes = Integer.parseInt(clockDisplay.getTime().substring(3, 5));
        hours = Integer.parseInt(clockDisplay.getTime().substring(0, 2));

        // This involves some serious black magic to get the code
        //  to run in the FX application thread rather than
        //  in the timer thread.

        Platform.runLater(() -> drawClock(gc));
    }

    /**
     * (Re)draws the clock at each timer tick.
     *
     * @param gc Graphics context with drawing methods.
     */

    public void drawClock(GraphicsContext gc) {
        final double HEIGHT = canvas.getHeight();
        final double WIDTH = canvas.getWidth();
        // clears the canvas and draws the clock outline
        gc.clearRect(0, 0, WIDTH, HEIGHT);
        gc.setLineWidth(2);
        gc.strokeOval((WIDTH / 2) - 150, (HEIGHT / 2) - 150, 300, 300);
        gc.setStroke(Color.BLACK);

        // draw the seconds hand
        gc.beginPath();
        gc.moveTo((WIDTH / 2), (HEIGHT / 2));
        gc.lineTo((WIDTH / 2) + 140 * Math.cos((2 * Math.PI - seconds * 6 * Math.PI / 180) - Math.PI / 2), (HEIGHT / 2) + 140 * Math.sin((2 * Math.PI - seconds * 6 * Math.PI / 180) - Math.PI / 2));
        gc.closePath();
        gc.stroke();

        // advances on every tick


        // draw the minutes hand
        gc.beginPath();
        gc.moveTo((WIDTH / 2), (HEIGHT / 2));
        gc.lineTo((WIDTH / 2) + 110 * Math.cos(-(Math.PI/2)-(2*Math.PI/3600)*(60*minutes+seconds)), (HEIGHT / 2) + 110 * Math.sin(-(Math.PI/2)-(2*Math.PI/3600)*(60*minutes+seconds)));
        gc.closePath();
        gc.stroke();

        //draw the hours hand
        gc.beginPath();
        gc.moveTo((WIDTH / 2), (HEIGHT / 2));
        gc.lineTo((WIDTH / 2) + 70 * Math.cos(-(Math.PI/2)-(2*Math.PI/43200)*(3600*hours+60*minutes+seconds)), (HEIGHT / 2) + 70 * Math.sin(-(Math.PI/2)-(2*Math.PI/43200)*(3600*hours+60*minutes+seconds)));
        gc.closePath();
        gc.stroke();


    }

}