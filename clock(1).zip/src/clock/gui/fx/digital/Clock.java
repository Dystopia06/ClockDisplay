package clock.gui.fx.digital;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import clock.ClockDisplay;
import timer.MyTimer;
import timer.TimerEvent;
import timer.TimerListener;


/**
 * A very simple GUI (graphical user interface) for the clock display.
 * This version uses the minimum JavaFX possible.
 * There are however a couple of curiosities:
 * - There seems to be no way to get a reference to this object from
 *   outside this object. So we can't register it directly as a
 *   timer listener with a timer event source. Instead we use a static
 *   method to inject a timer event source into this class, where
 *   we can then register the current object. A hack until something
 *   better comes up.
 * - Things run in different threads. The timer runs in its own thread,
 *   the FX application runs in another thread. This creates a few
 *   issues for the timer listener method affecting the GUI - they must
 *   run in the same thread.
 *
 * @author Michael Kölling and David J. Barnes
 * @author Peter Sander
 */
public class Clock extends Application implements TimerListener {
    private static MyTimer timer;
    private final ClockDisplay clockDisplay;
    private Label lbl = null;  // = new Label("Didn't say nuthin'");

    /**
     * Constructor builds a clock display which determines how the time
     * will be displayed.
     */
    public Clock() {
        clockDisplay = new ClockDisplay();
    }

    /**
     * This is kind of a kluge in order to inject a timer object.
     * It must be invoked before main.
     *
     * @param timer A timer event source.
     */
    public static void setTimer(MyTimer timer) {
        Clock.timer = timer;
    }

    /**
     * Called automagically upon launching the application. Runs in the
     * FX initialization thread, not the FX application thread. Beware.
     * Registers the current object as a timer listener.
     */
    @Override
    public void init() {
        timer.addTimerListener(this);
    }

    @Override
    public void stop() {
        System.out.println("Outta here");
    }

    /**
     * Called automagically upon launching the application. Runs in the
     * FX application thread.
     */
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("FX-based Clock");
        BorderPane root = new BorderPane();
        // time-showing label
        lbl = new Label("00:00:00");
        lbl.setFont(Font.font(48));
        root.setCenter(lbl);
        //adds pane for buttons
        FlowPane buttonPane = new FlowPane();
        root.setBottom(buttonPane);
        buttonPane.setAlignment(Pos.CENTER);
        // add start button
        Button startBtn = new Button("Start");
        startBtn.setOnAction(evt -> timer.start());
        buttonPane.getChildren().add(startBtn);
        // add pause button
        Button pauseBtn = new Button("Pause");
        pauseBtn.setOnAction(evt -> Clock.timer.pause());
        buttonPane.getChildren().add(pauseBtn);
        // add reset button
        Button resetBtn = new Button("Reset");
        resetBtn.setOnAction(evt -> {
            clockDisplay.setTime(0, 0, 0);
            lbl.setText(clockDisplay.getTime());
        });
        buttonPane.getChildren().add(resetBtn);
        //add quit button
        Button quitBtn = new Button("Quit");
        quitBtn.setOnAction(evt -> Platform.exit());
        buttonPane.getChildren().add(quitBtn);
        // constructs scene
        primaryStage.setScene(new Scene(root, 300, 250));
        primaryStage.show();
    }

    /**
     * Obligatory TimerListener method.
     *
     * @param evt The event fired by a TimerEvent source.
     */
    @Override
    public void tick(TimerEvent evt) {
        clockDisplay.timeTick();
        // This involves some serious black magic to get the code
        //  to run in the FX application thread rather than
        //  in the timer thread.
        Platform.runLater(() -> lbl.setText(clockDisplay.getTime()));
    }

}