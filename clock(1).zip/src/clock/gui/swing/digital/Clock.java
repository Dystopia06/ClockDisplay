package clock.gui.swing.digital;

import clock.ClockDisplay;
import timer.TimerEvent;
import timer.TimerListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;



public class Clock implements TimerListener {
    private final ClockDisplay clockDisplay;
    private JFrame frame;
    private JLabel label;

    public Clock() {
        makeFrame();
        clockDisplay = new ClockDisplay();
    }
    /**
     * Create the Swing frame and its content.
     */
    private void makeFrame() {
        frame = new JFrame("Swing-based Clock");
        JPanel contentPane = (JPanel) frame.getContentPane();
        contentPane.setBorder(new EmptyBorder(1, 60, 1, 60));

        // Specify the layout manager with nice spacing
        contentPane.setLayout(new BorderLayout(12, 12));

        // Create the image pane in the center
        label = new JLabel("00:00:00", SwingConstants.CENTER);
        Font displayFont = label.getFont().deriveFont(96.0f);
        label.setFont(displayFont);
        contentPane.add(label, BorderLayout.CENTER);

        frame.pack();

        // place the frame at the center of the screen and show
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(d.width / 2 - frame.getWidth() / 2,
                d.height / 2 - frame.getHeight() / 2);
        frame.setVisible(true);
    }

    public void tick(TimerEvent evt) {
        clockDisplay.timeTick();
        label.setText(clockDisplay.getTime());

    }
}

